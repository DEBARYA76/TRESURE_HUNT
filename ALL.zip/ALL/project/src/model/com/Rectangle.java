package model.com;

public class Rectangle extends Shape
{
	public void printRectangle()
	{System.out.println("This is a Rectangular Shape.");
	}
}
