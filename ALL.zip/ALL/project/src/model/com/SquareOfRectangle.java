package model.com;

public class SquareOfRectangle extends Rectangle
{
	public void printSquare()
	{System.out.println("Square is a rectangle");
	}
}
