package model.com;

public class Circle extends Shape
{
	public void printCircle()
	{System.out.println("This is a Circlular  Shape.");
	}
}
