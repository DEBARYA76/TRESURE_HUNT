package model.com;

public class Shape {
	public void Shape()
	{System.out.println("This is a  Shape.");
	}

}
