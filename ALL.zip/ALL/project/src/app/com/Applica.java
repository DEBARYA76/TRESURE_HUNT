package app.com;

import model.com.*;

public class Applica {

	public static void main(String[] args) {
		SquareOfRectangle square =new SquareOfRectangle();
		square.printSquare();
		square.printRectangle();
		square.Shape();
	}
}
