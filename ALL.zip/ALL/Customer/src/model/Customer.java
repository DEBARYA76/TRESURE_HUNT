package model;

public class Customer {

	private  String name;

	private String password;
	private String location;


	public Customer(String name,String password,String location)
	{
		this.name=name;
		this.password=password;
		this.location=location;

	}


	public void setname(String newname)
	{
		this.name=newname;	

	}
	public String getname()
	{
		return this.name;
	}


	public void setlocation(String newlocation)
	{
		this.location=newlocation;	

	}
	public String getlocation()
	{
		return this.location;
	}
	public void setpassword(String newpassword)
	{
		this.password=newpassword;	

	}
	public String getpassword()
	{
		return this.password;
	}
	
	public String toString() {
		return "User [name is " + name + ", location is  " + location + ", && password is " + password + "]";
	}


	
	




}
