package App;

import java.text.ParseException;
import java.util.Scanner;

import model.Customer;

public class AppMain 
{
	public Customer customer;

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);


		System.out.println("Welcome to Online Registration.");
		System.out.println("Enter name:");
		String name=scanner.nextLine();
		System.out.println("Enter password");
		String password=scanner.nextLine();
		System.out.println("Enter location");
		String location=scanner.nextLine();

		Customer customer=new Customer(name,password,location);
		System.out.println("Thanks.The customer enrolled have the details:");
		System.out.println(customer);


		System.out.println("Now you can update the details.Press 1 or 2 or 3 to update name or password or location:");
		int i=scanner.nextInt();

		switch(i)
		{
		case 1:
		{
			scanner.nextLine();
			System.out.println("Enter name:");
			String upname=scanner.nextLine();
			customer.setname(upname);
			System.out.println("Thank You ! Successfully updated");
			break;
		}
		case 2:
		{
			scanner.nextLine();
			System.out.println("Enter password");
			String uppassword=scanner.nextLine();
			customer.setpassword(uppassword);
			System.out.println("Thank You ! Successfully updated");
			break;
		}
		case 3:
		{
			scanner.nextLine();
			System.out.println("Enter location");
			String uplocation=scanner.nextLine();
			customer.setlocation(uplocation);
			System.out.println("Thank You ! Successfully updated");

			break;
		}
		default:
		{System.out.println("ENTER VALID");
		}
		}if(i==1 || i==2 ||i==3)
		{
			System.out.println("Thanks.You are all set.The updated details are");
			System.out.println("Name = " +customer.getname() );
			System.out.println("Passwrod = " + customer.getpassword());
			System.out.println("Location = "+ customer.getlocation());
		}



	}
}