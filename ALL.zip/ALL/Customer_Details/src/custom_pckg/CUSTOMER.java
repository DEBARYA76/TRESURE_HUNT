package custom_pckg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CUSTOMER {

	public static void main(String[] args)throws IOException
	{
		// TODO Auto-generated method stub
		InputStreamReader read =new InputStreamReader(System.in);
		BufferedReader br =new BufferedReader (read);
		
		System.out.println("WELCOME TO OUR SHOP !!!!!!");
		System.out.println("CUSTOMER DETAILS");
		System.out.println("ENTER THE YOUR NAME::: ");
		String name=br.readLine();
		System.out.println("ENTER YOUR AGE:::");
		int ag =Integer.parseInt(br.readLine());
		System.out.println("ENTER YOUR GENDER  (MALE/FEMALE):::");
		String gender=br.readLine();
		System.out.println("MAILING FROM ");
		String place=br.readLine();
	    System.out.println("YOUR DETAILS");
		System.out.println("WELCOME,"+name);
		System.out.println("YOUR AGE:"+ag);
		System.out.println("GENDER:"+gender);	
		System.out.println("Mailing From:"+place);

	}

}
