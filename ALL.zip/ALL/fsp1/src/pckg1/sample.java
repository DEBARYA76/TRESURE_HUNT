package pckg1;

public class sample {

	public static void main(String[] args) {
		System.out.println("Hello,I am Debarya");
		
		class StaticExample{
			 
			 static int x; // x is variable of int type - declaration
			 
			 int y; // non- static variable
			 
			 // the method is a static method or class method
			 static void method1(){
			  x = 10;
			  //System.out.println(" I am a static method");
			  System.out.println(x);
			 }
			}
			public class StaticDemo {

			 public static void main(String[] args) {
			  StaticDemo.main();
			 }
			 
			 // method overloading - static polymorphism
			 static void main(){
			  StaticExample.method1(); // way of calling static method
			  System.out.print("Static  main method");
			 }
			}
	}

}
