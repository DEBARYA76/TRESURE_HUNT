package pckg1;

public class computing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
