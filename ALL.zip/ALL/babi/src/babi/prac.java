package babi;

import java.util.Scanner;

public class prac {
	public static void main(String args[] ) throws Exception {
		Scanner sc=new Scanner (System.in);
		int t=sc.nextInt();
		if(t>=1 &&t<=100){
			int arr[][]=new int[t][4];
			int arr2[]=new int[t];
			int i;
			for( i=0;i<t;i++)
			{
				for(int j=0;j<3;j++)
				{
					
					
					arr[i][j]=sc.nextInt();
					}
				
			}

			for(i=0;i<t;i++){
				arr2[i]=arr[i][0]+(arr[i][1]*(arr[i][2]-1));}
			for(i=0;i<t;i++)
			{ System.out.println(arr2[i]);}

		}


	}
}