package babi;



	import java.io.*;
	import java.util.*;
	/*public class CandidateCode {
	    public static void main(String args[] ) throws Exception {*/

	    	import java.util.ArrayList;
	import java.util.Map;
	import java.util.Random;

	class Coord
	{
	    public int x, y;

	    public Coord(int x, int y)
	    {
	        this.x = x;
	        this.y = y;
	    }

	    public String toString(){
	        return "(" + x + "," + y + ")";
	    }
	}

	public class CandidateCode {

	    private static final int ROW = 9;
	    private static final int COL = 9;
	    private static int  LEFT_TOP = 0;
	    private static int  TOP = 1;
	    private static int  RIGHT_TOP = 2;
	    private static int  RIGHT = 3;
	    private static int  RIGHT_BOTTOM = 4;
	    private static int  BOTTOM = 5;
	    private static int  LEFT_BOTTOM = 6;
	    private static int  LEFT = 7;
	    private static int  DIRECTION_COUNT = 8;

	    public static void main(String[] args) {

	        boolean grid[][] = new boolean[ROW][COL];
	        fill(grid);
	        print(grid);
	        ArrayList<Map.Entry<Coord,ArrayList<Coord>>> connectedCities = getConnectedCities(grid);
	        printCities(connectedCities);

	    }

	    static private void fill(boolean grid[][])
	    {
	        final Random rnd = new Random();
	        for (int r = 0; r < ROW; r++)
	            for (int c = 0; c < COL; c++)
	                grid[r][c] = rnd.nextBoolean();
	    }

	    static private void print(boolean grid[][])
	    {
	        for (int r = 0; r < ROW; r++){
	            for(int c = 0; c < COL; c++){
	                System.out.print(grid[r][c] ? "1" : "0");
	            }
	            System.out.println();
	        }
	    }

	    static private void printCities(ArrayList<Map.Entry<Coord,ArrayList<Coord>>> connectedCities)
	    {
	        if (connectedCities.isEmpty())
	        {
	            System.out.println("Connected city is not existing");
	            return;
	        }
	        for (int index = 0; index < connectedCities.size(); index++)
	        {
	            Map.Entry<Coord,ArrayList<Coord>> item = connectedCities.get(index);
	            System.out.print("City " + item.getKey().toString() + " is connected to: ");

	            ArrayList<Coord> conCities = item.getValue();
	            for (int idx = 0; idx < conCities.size(); idx++)
	                System.out.print(conCities.get(idx).toString() + (idx + 1 == conCities.size() ? " " : ", "));
	        }
	    }

	    static private ArrayList<Map.Entry<Coord,ArrayList<Coord>>> getConnectedCities(boolean grid[][])
	    {
	        ArrayList<Map.Entry<Coord,ArrayList<Coord>>> cities = new ArrayList<Map.Entry<Coord,ArrayList<Coord>>>();
	        Coord points[] = new Coord[DIRECTION_COUNT];
	        for (int rowIndex = 0; rowIndex < ROW; rowIndex++)
	        {
	            for (int colIndex = 0; colIndex < COL; colIndex++)
	            {
	                if (grid[colIndex][rowIndex]) // if this city is marked
	                {
	                    points[LEFT] = new Coord(colIndex - 1, rowIndex);
	                    points[LEFT_TOP] = new Coord(colIndex-1, rowIndex-1);
	                    points[TOP] = new Coord( colIndex, rowIndex - 1);
	                    points[RIGHT_TOP] = new Coord(colIndex + 1, rowIndex - 1);
	                    points[RIGHT] = new Coord(colIndex + 1, rowIndex);
	                    points[RIGHT_BOTTOM] = new Coord(colIndex + 1, rowIndex + 1);
	                    points[BOTTOM] = new Coord(colIndex, rowIndex + 1);
	                    points[LEFT_BOTTOM] = new Coord(colIndex -1, rowIndex + 1);

	                    for (int dirIndex = 0; dirIndex < DIRECTION_COUNT; dirIndex++)
	                    {
	                        final ArrayList<Coord> conCities = new ArrayList<Coord>();
	                        Coord point = points[dirIndex];
	                        if (isValidCoord(point) && grid[point.y][point.x])
	                            conCities.add(point);

	                        if (!conCities.isEmpty()){
	                            final int finalRowIndex = rowIndex;
	                            final int finalColIndex = colIndex;
	                            cities.add(new Map.Entry<Coord, ArrayList<Coord>>(){
	                                public Coord getKey(){
	                                    return new Coord(finalColIndex, finalRowIndex);
	                                }

	                                public ArrayList<Coord> getValue(){
	                                    return conCities;
	                                }

	                                @Override
	                                public ArrayList<Coord> setValue(ArrayList<Coord> value){
	                                    return null;
	                                }
	                            });
	                        }
	                    }
	                }
	            }
	        }
	        return cities;
	    }

	    static private boolean isValidCoord(Coord c)
	    {
	        if (c.x < 0 || c.y < 0)
	            return  false;
	        if (c.x >= COL || c.y >= ROW )
	            return false;
	        return true;
	    }
	}






