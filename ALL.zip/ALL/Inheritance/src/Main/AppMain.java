package Main;
import child.*;
public class AppMain extends Parent {

	public static void main(String[] args) 
	{
		//Parent ob=new Parent();
		printP();
		Child obj=new Child();
		obj.printch();

		

	}

}
