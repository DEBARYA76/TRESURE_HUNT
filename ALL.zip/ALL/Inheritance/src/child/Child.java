package child;

public class Child extends Parent
{
	public  void printch()
	{
		
		System.out.println("This is a child class!!");

		
		
	}
	
	
	
}
