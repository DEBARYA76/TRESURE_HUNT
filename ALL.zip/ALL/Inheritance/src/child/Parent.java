package child;
import child.*;
import Main.*;
public class Parent {
	protected static void printP()
	{
		
		System.out.println("This is a Parent class!!");

		
		
	}

	
}
