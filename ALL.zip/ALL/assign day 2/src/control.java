
public class control {

	public static void main(String[] args) {
		int pm=40;
		int obm =60;
		int obm2 =54;
		int tm =obm+obm2;
		
		
		System.out.print("total marks acquired=");
		System.out.println(tm);
		System.out.print("pass marks =");
		System.out.println(pm);
		
		if(obm>= pm && obm2 >= pm)
			System.out.println("congrats,you have passed");
		else if (obm >= pm || obm2 >=pm)
			System.out.println("good luck ,ou hve passed fortunately");
		else 
			System.out.println("better luck next time .you have failed");
		
		
			
		
	}

}
