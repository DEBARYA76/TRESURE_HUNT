
public class usernaame {

	public static void main(String[] args) {
		String username="Debarya01";
		String password="abcd1234";
		
		System.out.println("WELCOME TO CRACK JOB: LOGIN TO CONTINUE");
		String unip="Debarya01";
		String pip ="abcd1234";
		
		if(username == unip)
			System.out.println("USERNAME EXISTS");
		else
			System.out.println("USER NOT EXIST");
		if(username == unip && password == pip)
			System.out.println("LOGGED IN SUCCEESFULLY");
		else
			System.out.println("LOGIN CREDENTIAL ARE NOT AVAILABLE");
		
		

	}

}
