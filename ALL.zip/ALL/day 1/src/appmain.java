/**
 * 
 */

/**
 * @author Debarya
 *
 */
public class appmain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("hiiiii,I am DEBARYA .I LOVE TO DO JAVA");
System.out.println("Ths is Day 1 ");
String fname ="DEBARYA";
String lname ="Pal";
String name = "";
name= fname + " " +lname;
System.out.println(name);
int i =544;
double p =56.09;
double sum =0.0;


sum = i+p;
int sum2=(int)sum;
System.out.println(sum);
System.out.println(sum2);



System.out.println();
	}

}
