module CAR_DETAILS {
}