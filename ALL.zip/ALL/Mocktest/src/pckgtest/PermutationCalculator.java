package pckgtest;
import java.util.ArrayList;

import java.util.Arrays;
import java.util.List;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PermutationCalculator
{

	public List<String> permutations(String inputStr)
	{
		if (inputStr == null)
			return null;

		final List<String> result = new ArrayList<>();
		if (inputStr.length() < 2) {

			result.add(inputStr);
			return result;
		}

		final List<String> permutations = permutations(inputStr.substring(1));
		for (final String permutation : permutations) {
			for (int i = 0; i <= permutation.length(); i++) {
				String newPermutation = permutation.substring(0, i) 
						+ inputStr.charAt(0) + permutation.substring(i);
				result.add(newPermutation);
			}
		}
		return result;
	}

	public static void main(String[] args) throws IOException {

		InputStreamReader read =new InputStreamReader(System.in);
		BufferedReader br =new BufferedReader (read);
		PermutationCalculator permuter = new PermutationCalculator();
		String Str=br.readLine(); 
		List<String> perms = permuter.permutations(Str);
		System.out.println(Arrays.toString(perms.toArray()));

	}
}