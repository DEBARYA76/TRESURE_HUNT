package pckgtest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MovieTicketCalculator {

	public static void main(String[] args) throws NumberFormatException, IOException
	{
		InputStreamReader read =new InputStreamReader(System.in);
		BufferedReader br =new BufferedReader (read);
		System.out.println("Enter the no of ticket");
		int no_tic=Integer.parseInt(br.readLine());
		if( no_tic<5 ||  no_tic>40)
		{
			System.out.println("Minimum of 5 and Maximum of 40 Tickets");
			System.exit(0);
		}
		else
		{
			System.out.println("Do you want refreshment: "); 
			String r=br.readLine();
			System.out.println("Do you have coupon code:");
			String c=br.readLine();
			System.out.println("Enter the circle:");
			String circle=br.readLine();
			int refresh,tckt_amount;
			double discount,final_amount=0.0,amount=0.0;
			if(r.equalsIgnoreCase("y"))
				refresh=50* no_tic;
			else
				refresh=0;

			if(circle.equalsIgnoreCase("k"))
				tckt_amount=75* no_tic;
			else if(circle.equalsIgnoreCase("q"))
				tckt_amount=150* no_tic;
			else
				tckt_amount=0;

			if(no_tic>20) 
				discount=(10*(tckt_amount+refresh))/100;
			else
				discount=0;
			amount=((tckt_amount+refresh)-discount);
			if(c.equalsIgnoreCase("y"))
				final_amount=(amount*98)/100;
			else
				final_amount=amount;

			System.out.print("Ticket cost:    ");
			System.out.printf("%.2f",final_amount);

		}











	}

}
