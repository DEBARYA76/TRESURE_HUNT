package pckgtest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class GainCalculator {

	public static void main(String[] args) throws NumberFormatException, IOException {
		InputStreamReader read =new InputStreamReader(System.in);
		BufferedReader br =new BufferedReader (read);
		System.out.println("  Price of old scooter: ");
		double price=Double.parseDouble(br.readLine());
		System.out.println("The amount spent for repair:");
		double repairprice=Double.parseDouble(br.readLine());
		System.out.println("Sold Price:");
		double soldprice=Double.parseDouble(br.readLine());

		if(price<=0 ||soldprice<=0 ||repairprice<0 )
			System.out.println("Incorrect Inputs"); 
		else if(soldprice == (repairprice+price))
			System.out.println("Unable to calculate Gain Percentage");
		else
		{
			double gain=  ( soldprice- (repairprice+price));
			double gain_perc=(gain/(repairprice+price))*100;
			System.out.print("Gain percentage is  " );
			System.out.printf("%.2f",gain_perc); 	





		}

	}

}
