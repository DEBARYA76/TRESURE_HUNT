package pckgtest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BonusPointCalculator {

	public static void main(String[] args) throws NumberFormatException, IOException {
		InputStreamReader read =new InputStreamReader(System.in);
		BufferedReader br =new BufferedReader (read);
		System.out.println("Enter the distance travelled ");
		int dst=Integer.parseInt(br.readLine());


		if(dst<0)
			System.out.println("Invalid Input");
		else
		{ int podd=1,peven=1;
		while(dst>0)
		{
			int  r=dst % 10;
			podd*=r;
			dst=dst/10;
			if(dst==0)
				break;
			r=dst%10;
			peven*=r;
			dst/=10;


		}
		if( podd> peven)
			System.out.println("Your bonus points is "+podd);
		else if(podd < peven)
			System.out.println("Your bonus points is "+peven);
		else
			System.out.println("Your bonus points is "+(2*peven));
		}

	}

}
