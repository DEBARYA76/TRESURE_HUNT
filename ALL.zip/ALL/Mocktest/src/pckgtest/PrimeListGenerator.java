package pckgtest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PrimeListGenerator {

	public static void main(String[] args) throws NumberFormatException, IOException {

		InputStreamReader read =new InputStreamReader(System.in);
		BufferedReader br =new BufferedReader (read);

		int n1=Integer.parseInt(br.readLine());
		int n2=Integer.parseInt(br.readLine());


		if(n1<=0 || n2<=0  || (n1>n2))
			System.out.println("Provide valid input");

		else
		{

			while(n1<=n2)	
			{    
				int flag=0;
				for(int j=2;j<n1;j++)	
				{
					{
						if(n1%j==0)
						{flag=1;
						break;}

					}

				}if(flag==0)
					System.out.print(n1+" ");

				n1++;
			}
		}
	}
}


