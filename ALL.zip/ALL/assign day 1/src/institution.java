
public class institution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str =" Crack job";
		System.out.println(str);

	}

}
