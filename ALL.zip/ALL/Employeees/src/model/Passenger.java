package model;

public class Passenger {

	public Passenger(Object ticketid, Object name, String gender, String address) {
		// TODO Auto-generated constructor stub
	}

}
