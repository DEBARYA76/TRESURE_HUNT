package Model;

public class Triangle {
	public int side1;
	public int side2;
	public int side3;
	
	public  Triangle(int a,int b,int c)
	{
		this.side1=a;
		this.side2=b;
		this.side3=c;
	}

}
