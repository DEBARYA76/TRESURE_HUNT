package bill_pckg;

import java.util.Scanner;

public class BILLING {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("WELCOME");
		System.out.println("AVAILABLE ITEMS: \n Rs.100/pizza\r\n" + 
				"\r\n" + 
				"Rs.20/puffs\r\n" + 
				"\r\n" + 
				"Rs.10/cooldrink\r\n" );
		System.out.println("ENTER YOUR NAME ");
		String name =sc.nextLine();
		System.out.println(name+"    ENTER THE NO OF ITEMS YOU BROUGHT :");
		System.out.println("Enter the no of PIZZAS bought:\r\n" );
		int n1=sc.nextInt();
		System.out.println("Enter the no of PUFFS bought:\r\n" );
		int n2=sc.nextInt();
		System.out.println("Enter the no of COLD DRINKs bought:\r\n" );
		int n3=sc.nextInt();
        System.out.println("BILL of"+name);
        System.out.println("TOTAL NOs OF pizzas : "+n1);
        System.out.println("TOTAL NOs OF puffs: "+n2);
        System.out.println("TOTAL NOs OF cold drinks : "+n3);
        System.out.println("TOTAL PRICE: "+(n1*100 + n2*20 +n3*10));
        System.out.println("ENJOY THE SHOW");
		
		
	}

}
