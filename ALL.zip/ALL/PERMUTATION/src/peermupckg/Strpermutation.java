package peermupckg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Strpermutation {

	 private StringBuilder output = new StringBuilder();
	    private final String inputstring;
	    int l,t;
	    
	    public Strpermutation( final String str ){
	        inputstring = str;
	         l= inputstring.length();
	       
	    }
	    
	    
	    public static void main (String args[])throws  IOException
	    {
	    	
	    	InputStreamReader read =new InputStreamReader(System.in);
			BufferedReader br =new BufferedReader (read);
			System.out.println(" ENTER T :");
			int t=Integer.parseInt(br.readLine());
			if(t>=1 && t<=10)
			{   while(t!=0)
			{
				int n=Integer.parseInt(br.readLine());	
				int k=Integer.parseInt(br.readLine());
				if(n>=1 && n<=1000 && t>=1 && t<=100)
				{   
					
					
					System.out.println("enter the string \n");
					 String str=br.readLine();
					 if(str.length()==(n+k)) {
					Strpermutation combobj= new Strpermutation(str);
	                combobj.combine(k);
					 }
	                }
				 t--;
				}
	    }}
	    
	    public void combine(int i) { 
	    combine( 0,i ); }
	    private void combine(int start,int p ){
	    	int ctrl=0,m=0;
	        for( int i = start; i < inputstring.length(); ++i ){
	            output.append( inputstring.charAt(i) );
	            System.out.println(output);
	            System.out.println(p);
	            
	            if(output.length()==(l-p))
	            {
	            	ctrl++;
	            }
	            //int arr1[] = new int[t];
	            /*arr1[m]=ctrl;
	            m++;*/
	            System.out.println(ctrl-1);
	            
	            if ( i < inputstring.length() )
	            combine( i + 1);
	            output.setLength( output.length() - 1 );
	        }
	    }

}
