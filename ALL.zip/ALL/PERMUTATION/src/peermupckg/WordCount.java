package peermupckg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class WordCount {
	  
    static final int OUT = 0;
    static final int IN = 1;
      
    
    public  static int countWords(String str)
    {
        int state = OUT;
        int wc = 0;  
        int i = 0;
         
       int a=0;
        while (i < str.length())
        {
            
            if (str.charAt(i) == ' ' || str.charAt(i) == '\n'
                    || str.charAt(i) == '\t')
                state = OUT;
                 
      
            else if (state == OUT)
            {
                state = IN;
                ++wc;
            }
      
           
            ++i;
            a++;
        }System.out.println(a+(wc-2));
        return wc;
    } 
    
 
  public static void main(String args[]) throws IOException
    {
    	InputStreamReader read =new InputStreamReader(System.in);
		BufferedReader br =new BufferedReader (read);
		System.out.println("Enter the string ");
		 String str=br.readLine();
		 if(str.length()<=100) {
        System.out.println("No of words : " + countWords(str));
        
		 }
    }}