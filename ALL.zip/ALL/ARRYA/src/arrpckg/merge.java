package arrpckg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.io.*;
public class merge
{
	public static void main(String[] args)throws IOException
	{
		// TODO Auto-generated method stub
		InputStreamReader read =new InputStreamReader(System.in);
		BufferedReader br =new BufferedReader (read);
		
		int i;
		System.out.println("ENTER THE NUMBER OF USERS :");
		int n=Integer.parseInt(br.readLine());
		String users[] = new String[n];
		System.out.println("ENTER THE USERS:");
		for(i=0;i<n;i++)
		{
			 users[i] =br.readLine();
		}
		System.out.println("The email ids are:");
		for(i=0;i<n;i++)
		{
			System.out.println( users[i].toLowerCase() +"@crackjob.com");
		}
		
	}
}
