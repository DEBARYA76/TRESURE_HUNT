package loop1pckg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class variations_of_loop {

	public static void main(String[] args)throws IOException
	{
		
       
          InputStreamReader read =new InputStreamReader(System.in);
			BufferedReader br =new BufferedReader (read);
         /* System.out.println("ENTER THE NUMBER OF EMPLOYEES");
          int n= Integer.parseInt(br.readLine());
        
         
         while(i<=n)
         {
        	  System.out.println("ENTER YOUR NAME & SALARY for EMPLOYEE " +i+":::");
        	  String name =br.readLine();
        	  int salary=Integer.parseInt(br.readLine());
        	  if (salary<25000 && salary >=0)
        		  System.out.println(name + "  you are in LOW INCOME GROUP");
        	  else if (salary>=25000 && salary<60000)
        		  System.out.println(name + "  you are in MEDIUM INCOME GROUP");
        	  else
        		  System.out.println(name + "  you are in HIGH INCOME GROUP");
        	  
        	  
        	  i++;
        		  
        	  
        	  
          }*/
			
			
			int i;
			for(i=0;i<=10;i++)
			{
	        }
			System.out.println(i);
	}
}
