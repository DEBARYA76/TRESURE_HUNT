package carpckg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class car_directory 
{

		
			public static void main(String[] args)throws IOException
			{
				// TODO Auto-generated method stub
				InputStreamReader read =new InputStreamReader(System.in);
				BufferedReader br =new BufferedReader (read);
				
				System.out.println("WELCOME TO SHOWROOM !!!!!!");
				System.out.println("CAR DETAILS");
				System.out.println("ENTER THE CAR NAME::: ");
				String name=br.readLine();
				System.out.println("ENTER THE CAR NUMBER:::");
				int no =Integer.parseInt(br.readLine());
				System.out.println("ENTER THE PRICE OF A CAR:::");
				double p=Double.parseDouble(br.readLine());
			    System.out.println("YOUR CAR DETAILS");
				System.out.println("CAR NAME:"+name);
				System.out.println("CAR NUMBER:"+no);
				System.out.println("PRICE:"+p+"Rs only");
				
				
		        
				System.out.println("THANK YOU!!!");

			
			}

	


	}


