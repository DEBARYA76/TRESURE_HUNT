package username;
import java.util.*;
public class jeffy_app {

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("ENTER YOUR NAME:");
		String name =sc.nextLine();
		System.out.println("Welcome "+name);
		
	
		

	}

}
