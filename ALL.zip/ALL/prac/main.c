#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a=10,b=5,c=5;
    int d;
    d=b+c==a;
    printf("%d",d);
}
